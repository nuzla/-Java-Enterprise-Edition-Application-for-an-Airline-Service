/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tour;

import Entity.Reservationcb004603;
import Entity.Tourcb004603;
import Entity.Touristcb004603;
import Entity.Tourplancb004603;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.ejb.EJBException;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import utils.Reservation;
import utils.Tour;
import utils.TourPlan;
import utils.Tourist;

/**
 *
 * @author Nuzla
 */
@Stateless(mappedName = "tourFacade")
public class TourFacade implements TourFacadeRemote {

    @PersistenceContext
    private EntityManager em;

    private TourPlan DB2Entity(Tourplancb004603 tp) {
        TourPlan t = new TourPlan();

        t.setCapacity(tp.getCapacity());
        t.setTitle(tp.getTitle());
        t.setDetails(tp.getDetails());
        t.setTourid(tp.getTourid());

        return t;
    }

    private Tourplancb004603 Entity2DB(TourPlan tp) {
        Tourplancb004603 t = new Tourplancb004603();

        t.setCapacity(tp.getCapacity());
        t.setTitle(tp.getTitle());
        t.setDetails(tp.getDetails());
        t.setTourid(tp.getTourid());

        return t;
    }

    private Tour DB2Entity(Tourcb004603 tp) {
        Tour t = new Tour();
        t.setEndhotel(tp.getEndhotel());
        t.setEndtime(tp.getEndtime());
        t.setStarthotel(tp.getStarthotel());
        t.setStarttime(tp.getStarttime());
        t.setTourid(DB2Entity(tp.getTourid()));
        t.setTourno(tp.getTourno());

        return t;
    }

    private Tourcb004603 Entity2DB(Tour tp) {
        Tourcb004603 t = new Tourcb004603();
        t.setEndhotel(tp.getEndhotel());
        t.setEndtime(tp.getEndtime());
        t.setStarthotel(tp.getStarthotel());
        t.setStarttime(tp.getStarttime());
        t.setTourid(Entity2DB(tp.getTourid()));
        t.setTourno(tp.getTourno());

        return t;
    }

    private Reservation DB2Entity(Reservationcb004603 r) {
        Reservation t = new Reservation();
        t.setReservationno(r.getReservationno());
        t.setTourno(DB2Entity(r.getTourno()));
        t.setTouristid(DB2Entity(r.getTouristid()));

        return t;

    }

    private Reservationcb004603 Entity2DB(Reservation r) {
        Reservationcb004603 t = new Reservationcb004603();
        t.setReservationno(r.getReservationno());
        t.setTourno(Entity2DB(r.getTourno()));
        t.setTouristid(Entity2DB(r.getTouristid()));

        return t;
    }

    private Tourist DB2Entity(Touristcb004603 tourist) {
        Tourist t = new Tourist();
        t.setFname(tourist.getFname());
        t.setLname(tourist.getLname());
        t.setTouristid(tourist.getTouristid());
        return t;

    }

    private Touristcb004603 Entity2DB(Tourist tourist) {
        Touristcb004603 t = new Touristcb004603();
        t.setFname(tourist.getFname());
        t.setLname(tourist.getLname());
        t.setTouristid(tourist.getTouristid());
        return t;

    }

    private List<TourPlan> copyTourPlanToDetails(List<Tourplancb004603> tpdetails) {

        List<TourPlan> TourPlanList = new ArrayList<TourPlan>();
        Iterator<Tourplancb004603> i = tpdetails.iterator();
        while (i.hasNext()) {
            Tourplancb004603 tpd = i.next();

            TourPlanList.add(DB2Entity(tpd));
        }
        return TourPlanList;
    }

    private List<Tour> copyTourToDetails(List<Tourcb004603> tourdetails) {
        List<Tour> TourList = new ArrayList<>();

        for (Tourcb004603 tour : tourdetails) {

            TourList.add(DB2Entity(tour));
        }
        return TourList;
    }

    private List<Tourist> copyTouristToDetails(List<Touristcb004603> tpdetails) {

        List<Tourist> TouristList = new ArrayList<Tourist>();
        Iterator<Touristcb004603> i = tpdetails.iterator();
        while (i.hasNext()) {
            Touristcb004603 tpd = (Touristcb004603) i.next();
            TouristList.add(DB2Entity(tpd));
        }
        return TouristList;
    }

    private List<Reservation> copyReservationToDetails(List<Reservationcb004603> rdetails) {
        List<Reservation> TourList = new ArrayList<>();

        for (Reservationcb004603 tour : rdetails) {
            TourList.add(DB2Entity(tour));
        }

        return TourList;
    }

    public void createTourPlan(TourPlan details) {
        try {

            em.persist(Entity2DB(details));

        } catch (Exception ex) {
            throw new EJBException(ex);
        }
    }

    public void createTour(Tour details) {
        try {

            
            em.persist(Entity2DB(details));

        } catch (Exception ex) {
            throw new EJBException(ex);
        }
    }

    public void createTourist(Tourist details) {
        try {
            
            em.persist(Entity2DB(details));

        } catch (Exception ex) {
            throw new EJBException(ex);
        }
    }

    public void createReservation(Reservation details) {
        try {
        em.persist(Entity2DB(details)); 
          

        } catch (Exception ex) {
            throw new EJBException(ex);
        }
    }

    public void editTourPlan(TourPlan details) {
        try {

          
            em.merge(Entity2DB(details));

        } catch (Exception ex) {
            throw new EJBException(ex);
        }
    }

    public void editTour(Tour details) {
        try {

           
            em.merge(Entity2DB(details));

        } catch (Exception ex) {
            throw new EJBException(ex);
        }
    }

    public void editTourist(Tourist details) {
        try {
           
            em.merge(Entity2DB(details));

        } catch (Exception ex) {
            throw new EJBException(ex);
        }
    }

    public void editReservation(Reservation details) {
        try {
            em.merge(Entity2DB(details));

        } catch (Exception ex) {
            throw new EJBException(ex);
        }
    }

    public TourPlan getTourplancb004603(String tourId) {
        TourPlan tpDetails = null;
        try {
            Tourplancb004603 tour = em.find(Tourplancb004603.class, tourId);
            tpDetails =DB2Entity(tour);

        } catch (Exception ex) {
            throw new EJBException(ex);
        }
        return tpDetails;
    }

    public Tour getTourcb004603(String tourno) {
        Tour tDetails = null;
        try {
            Tourcb004603 tour = em.find(Tourcb004603.class, tourno);
            tDetails = DB2Entity(tour);
          

        } catch (Exception ex) {
            throw new EJBException(ex);
        }
        return tDetails;
    }

    public Tourist getTouristcb004603(String touristid) {
        Tourist tDetails = null;
        try {
            Touristcb004603 tour = em.find(Touristcb004603.class, touristid);
            tDetails =DB2Entity(tour);
            

        } catch (Exception ex) {
            throw new EJBException(ex);
        }
        return tDetails;
    }

    public Reservation getReservationcb004603(String reservationno) {
        Reservation rDetails = null;
        try {
            Reservationcb004603 tour = em.find(Reservationcb004603.class, reservationno);
            rDetails = DB2Entity(tour);
            

        } catch (Exception ex) {
            throw new EJBException(ex);
        }
        return rDetails;
    }
    
     public void removeTourplancb004603(String tourid) {
     try {
     Tourplancb004603 tp = em.find(Tourplancb004603.class, tourid);
     em.remove(tp);
     } catch (Exception ex) {
     throw new EJBException(ex);
     }
     }
    public void removeTourcb004603(String tourno) {
     try {
     Tourcb004603 t = em.find(Tourcb004603.class, tourno);
     em.remove(t);
     } catch (Exception ex) {
     throw new EJBException(ex);
     }
     }
    
    public void removeTouristcb004603(String touristid) {
     try {
     Touristcb004603 t= em.find(Touristcb004603.class, touristid);
     em.remove(t);
     } catch (Exception ex) {
     throw new EJBException(ex);
     }
     }
 public void removeReservationcb004603(String reservationno) {
     try {
     Reservationcb004603 r = em.find(Reservationcb004603.class, reservationno);
     em.remove(r);
     } catch (Exception ex) {
     throw new EJBException(ex);
     }
     }
 
  public List<TourPlan> getAllTourplancb004603() {
     List<Tourplancb004603> tp = new ArrayList<Tourplancb004603>();
     try {
     tp = (List<Tourplancb004603>) 
             em.createNamedQuery("Tourplancb004603.findAll")
     .getResultList();
     
    
     return copyTourPlanToDetails(tp);
     } catch (Exception ex) {
     throw new EJBException(ex);
     }
     }
public List<Tour> getAllTourcb004603() {
     List<Tourcb004603> t = null;
     try {
     t = (List<Tourcb004603>) 
             em.createNamedQuery("Tourcb004603.findAll")
     .getResultList();
     return copyTourToDetails(t);
     } catch (Exception ex) {
     throw new EJBException(ex);
     }
     }
 
 public List<Tourist> getAllTouristcb004603() {
     List<Touristcb004603> t = null;
     try {
     t = (List<Touristcb004603>) 
             em.createNamedQuery("Touristcb004603.findAll")
     .getResultList();
     return copyTouristToDetails(t);
     } catch (Exception ex) {
     throw new EJBException(ex);
     }
     }
  public List<Reservation> getAllReservationcb004603() {
     List<Reservationcb004603> t = null;
     try {
     t = (List<Reservationcb004603>) 
             em.createNamedQuery("Reservationcb004603.findAll")
     .getResultList();
     return copyReservationToDetails(t);
     } catch (Exception ex) {
     throw new EJBException(ex);
     }
     }
 
}
