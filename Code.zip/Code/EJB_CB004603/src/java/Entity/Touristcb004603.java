/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Nuzla
 */
@Entity
@Table(name = "TOURISTCB004603")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Touristcb004603.findAll", query = "SELECT t FROM Touristcb004603 t"),
    @NamedQuery(name = "Touristcb004603.findByTouristid", query = "SELECT t FROM Touristcb004603 t WHERE t.touristid = :touristid"),
    @NamedQuery(name = "Touristcb004603.findByFname", query = "SELECT t FROM Touristcb004603 t WHERE t.fname = :fname"),
    @NamedQuery(name = "Touristcb004603.findByLname", query = "SELECT t FROM Touristcb004603 t WHERE t.lname = :lname")})
public class Touristcb004603 implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "TOURISTID")
    private String touristid;
    @Size(max = 20)
    @Column(name = "FNAME")
    private String fname;
    @Size(max = 20)
    @Column(name = "LNAME")
    private String lname;
    @OneToMany(mappedBy = "touristid")
    private Collection<Reservationcb004603> reservationcb004603Collection;

    public Touristcb004603() {
    }

    public Touristcb004603(String touristid, String fname, String lname) {
        this.touristid = touristid;
        this.fname = fname;
        this.lname = lname;
    }

    public Touristcb004603(String touristid) {
        this.touristid = touristid;
    }

    public String getTouristid() {
        return touristid;
    }

    public void setTouristid(String touristid) {
        this.touristid = touristid;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public void addReservation(Reservationcb004603 reservation) {
        this.getReservationcb004603Collection().add(reservation);
    }

    public void dropReservation(Reservationcb004603 reservation) {
        this.getReservationcb004603Collection().remove(reservation);
    }

    @XmlTransient
    public Collection<Reservationcb004603> getReservationcb004603Collection() {
        return reservationcb004603Collection;
    }

    public void setReservationcb004603Collection(Collection<Reservationcb004603> reservationcb004603Collection) {
        this.reservationcb004603Collection = reservationcb004603Collection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (touristid != null ? touristid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Touristcb004603)) {
            return false;
        }
        Touristcb004603 other = (Touristcb004603) object;
        if ((this.touristid == null && other.touristid != null) || (this.touristid != null && !this.touristid.equals(other.touristid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entity.Touristcb004603[ touristid=" + touristid + " ]";
    }

}
