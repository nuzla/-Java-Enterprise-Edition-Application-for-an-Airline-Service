/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Nuzla
 */
@Entity
@Table(name = "TOURCB004603")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tourcb004603.findAll", query = "SELECT t FROM Tourcb004603 t"),
    @NamedQuery(name = "Tourcb004603.findByTourno", query = "SELECT t FROM Tourcb004603 t WHERE t.tourno = :tourno"),
    @NamedQuery(name = "Tourcb004603.findByStarthotel", query = "SELECT t FROM Tourcb004603 t WHERE t.starthotel = :starthotel"),
    @NamedQuery(name = "Tourcb004603.findByEndhotel", query = "SELECT t FROM Tourcb004603 t WHERE t.endhotel = :endhotel"),
    @NamedQuery(name = "Tourcb004603.findByStarttime", query = "SELECT t FROM Tourcb004603 t WHERE t.starttime = :starttime"),
    @NamedQuery(name = "Tourcb004603.findByEndtime", query = "SELECT t FROM Tourcb004603 t WHERE t.endtime = :endtime")})
public class Tourcb004603 implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "TOURNO")
    private String tourno;
    @Size(max = 20)
    @Column(name = "STARTHOTEL")
    private String starthotel;
    @Size(max = 20)
    @Column(name = "ENDHOTEL")
    private String endhotel;
    @Column(name = "STARTTIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date starttime;
    @Column(name = "ENDTIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date endtime;
    @JoinColumn(name = "TOURID", referencedColumnName = "TOURID")
    @ManyToOne
    private Tourplancb004603 tourid;
    @OneToMany(mappedBy = "tourno")
    private Collection<Reservationcb004603> reservationcb004603Collection;

    public Tourcb004603() {
    }

    public Tourcb004603(String tourno,Tourplancb004603 tourid,String starthotel,String endhotel,Date starttime,Date endtime) {
        this.tourno=tourno;
        this.tourid=tourid;
        this.starthotel=starthotel;
        this.endhotel=endhotel;
        this.starttime=starttime;
        this.endtime=endtime;
    }

    public Tourcb004603(String tourno) {
        this.tourno = tourno;
    }

    public String getTourno() {
        return tourno;
    }

    public void setTourno(String tourno) {
        this.tourno = tourno;
    }

    public String getStarthotel() {
        return starthotel;
    }

    public void setStarthotel(String starthotel) {
        this.starthotel = starthotel;
    }

    public String getEndhotel() {
        return endhotel;
    }

    public void setEndhotel(String endhotel) {
        this.endhotel = endhotel;
    }

    public Date getStarttime() {
        return starttime;
    }

    public void setStarttime(Date starttime) {
        this.starttime = starttime;
    }

    public Date getEndtime() {
        return endtime;
    }

    public void setEndtime(Date endtime) {
        this.endtime = endtime;
    }

    public Tourplancb004603 getTourid() {
        return tourid;
    }

    public void setTourid(Tourplancb004603 tourid) {
        this.tourid = tourid;
    }

    public void addReservation(Reservationcb004603 reservation) {
        this.getReservationcb004603Collection().add(reservation);
    }

    public void dropReservation(Reservationcb004603 reservation) {
        this.getReservationcb004603Collection().remove(reservation);
    }

    @XmlTransient
    public Collection<Reservationcb004603> getReservationcb004603Collection() {
        return reservationcb004603Collection;
    }

    public void setReservationcb004603Collection(Collection<Reservationcb004603> reservationcb004603Collection) {
        this.reservationcb004603Collection = reservationcb004603Collection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (tourno != null ? tourno.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tourcb004603)) {
            return false;
        }
        Tourcb004603 other = (Tourcb004603) object;
        if ((this.tourno == null && other.tourno != null) || (this.tourno != null && !this.tourno.equals(other.tourno))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entity.Tourcb004603[ tourno=" + tourno + " ]";
    }

}
