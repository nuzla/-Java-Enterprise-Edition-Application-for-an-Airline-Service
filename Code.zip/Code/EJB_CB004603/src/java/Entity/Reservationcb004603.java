/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Nuzla
 */
@Entity
@Table(name = "RESERVATIONCB004603")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Reservationcb004603.findAll", query = "SELECT r FROM Reservationcb004603 r"),
    @NamedQuery(name = "Reservationcb004603.findByReservationno", query = "SELECT r FROM Reservationcb004603 r WHERE r.reservationno = :reservationno")})
public class Reservationcb004603 implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "RESERVATIONNO")
    private String reservationno;
    @JoinColumn(name = "TOURISTID", referencedColumnName = "TOURISTID")
    @ManyToOne
    private Touristcb004603 touristid;
    @JoinColumn(name = "TOURNO", referencedColumnName = "TOURNO")
    @ManyToOne
    private Tourcb004603 tourno;

    public Reservationcb004603() {
    }

    public Reservationcb004603(String reservationno,Tourcb004603 tourno,Touristcb004603 touristid) {
        this.reservationno=reservationno;
        this.tourno=tourno;
        this.touristid=touristid;
    }

    public Reservationcb004603(String reservationno) {
        this.reservationno = reservationno;
    }

    public String getReservationno() {
        return reservationno;
    }

    public void setReservationno(String reservationno) {
        this.reservationno = reservationno;
    }

    public Touristcb004603 getTouristid() {
        return touristid;
    }

    public void setTouristid(Touristcb004603 touristid) {
        this.touristid = touristid;
    }

    public Tourcb004603 getTourno() {
        return tourno;
    }

    public void setTourno(Tourcb004603 tourno) {
        this.tourno = tourno;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (reservationno != null ? reservationno.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Reservationcb004603)) {
            return false;
        }
        Reservationcb004603 other = (Reservationcb004603) object;
        if ((this.reservationno == null && other.reservationno != null) || (this.reservationno != null && !this.reservationno.equals(other.reservationno))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entity.Reservationcb004603[ reservationno=" + reservationno + " ]";
    }

}
