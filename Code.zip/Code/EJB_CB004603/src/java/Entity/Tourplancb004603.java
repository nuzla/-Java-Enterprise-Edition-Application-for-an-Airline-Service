/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Nuzla
 */
@Entity
@Table(name = "TOURPLANCB004603")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tourplancb004603.findAll", query = "SELECT t FROM Tourplancb004603 t"),
    @NamedQuery(name = "Tourplancb004603.findByTourid", query = "SELECT t FROM Tourplancb004603 t WHERE t.tourid = :tourid"),
    @NamedQuery(name = "Tourplancb004603.findByTitle", query = "SELECT t FROM Tourplancb004603 t WHERE t.title = :title"),
    @NamedQuery(name = "Tourplancb004603.findByDetails", query = "SELECT t FROM Tourplancb004603 t WHERE t.details = :details"),
    @NamedQuery(name = "Tourplancb004603.findByCapacity", query = "SELECT t FROM Tourplancb004603 t WHERE t.capacity = :capacity")})
        

public class Tourplancb004603 implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "TOURID")
    private String tourid;
    @Size(max = 20)
    @Column(name = "TITLE")
    private String title;
    @Size(max = 20)
    @Column(name = "DETAILS")
    private String details;
    @Column(name = "CAPACITY")
    private Short capacity;
    @OneToMany(mappedBy = "tourid")
    private Collection<Tourcb004603> tourcb004603Collection;

    public Tourplancb004603() {
    }

    public Tourplancb004603(String tourid, String title, String details, Short capacity) {
        this.tourid = tourid;
        this.title = title;
        this.details = details;
        this.capacity = capacity;
    }

    public Tourplancb004603(String tourid) {
        this.tourid = tourid;
    }

    public String getTourid() {
        return tourid;
    }

    public void setTourid(String tourid) {
        this.tourid = tourid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public Short getCapacity() {
        return capacity;
    }

    public void setCapacity(Short capacity) {
        this.capacity = capacity;
    }

    public void addTour(Tourcb004603 tour) {
        this.getTourcb004603Collection().add(tour);
        
    }

    public void dropTour(Tourcb004603 tour) {
        this.getTourcb004603Collection().remove(tour);
    }

    @XmlTransient
    public Collection<Tourcb004603> getTourcb004603Collection() {
        return tourcb004603Collection;
    }

    public void setTourcb004603Collection(Collection<Tourcb004603> tourcb004603Collection) {
        this.tourcb004603Collection = tourcb004603Collection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (tourid != null ? tourid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tourplancb004603)) {
            return false;
        }
        Tourplancb004603 other = (Tourplancb004603) object;
        if ((this.tourid == null && other.tourid != null) || (this.tourid != null && !this.tourid.equals(other.tourid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entity.Tourplancb004603[ tourid=" + tourid + " ]";
    }

}
