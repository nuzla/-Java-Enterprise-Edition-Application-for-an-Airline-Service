/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

/**
 *
 * @author Nuzla
 */
public class Tourist implements java.io.Serializable {

    private String touristid;
    private String fname;
    private String lname;

    public Tourist() {
    }

    public Tourist(String touristid, String fname, String lname) {
        this.touristid = touristid;
        this.fname = fname;
        this.lname = lname;
    }

    /**
     * @return the touristid
     */
    public String getTouristid() {
        return touristid;
    }

    /**
     * @param touristid the touristid to set
     */
    public void setTouristid(String touristid) {
        this.touristid = touristid;
    }

    /**
     * @return the fname
     */
    public String getFname() {
        return fname;
    }

    /**
     * @param fname the fname to set
     */
    public void setFname(String fname) {
        this.fname = fname;
    }

    /**
     * @return the lname
     */
    public String getLname() {
        return lname;
    }

    /**
     * @param lname the lname to set
     */
    public void setLname(String lname) {
        this.lname = lname;
    }

    @Override
    public String toString() {
        return "Tourist{" + "touristid=" + touristid + ", fname=" + fname + ", lname=" + lname + '}';
    }

}
