/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

/**
 *
 * @author Nuzla
 */
public class TourPlan implements java.io.Serializable {

    private String tourid;
    private String title;
    private String details;
    private short capacity;

    public TourPlan() {
    }

    public TourPlan(String tourid, String title, String details, short capacity) {
        this.tourid = tourid;
        this.title = title;
        this.details = details;
        this.capacity = capacity;
    }

    /**
     * @return the tourid
     */
    public String getTourid() {
        return tourid;
    }

    /**
     * @param tourid the tourid to set
     */
    public void setTourid(String tourid) {
        this.tourid = tourid;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the details
     */
    public String getDetails() {
        return details;
    }

    /**
     * @param details the details to set
     */
    public void setDetails(String details) {
        this.details = details;
    }

    /**
     * @return the capacity
     */
    public short getCapacity() {
        return capacity;
    }

    /**
     * @param capacity the capacity to set
     */
    public void setCapacity(short capacity) {
        this.capacity = capacity;
    }

    @Override
    public String toString() {
        return "TourPlan{" + "tourid=" + tourid + ", title=" + title + ", details=" + details + ", capacity=" + capacity + '}';
    }

}
