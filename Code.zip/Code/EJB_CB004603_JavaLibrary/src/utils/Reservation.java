/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

/**
 *
 * @author Nuzla
 */
public class Reservation implements java.io.Serializable {

  
  

    private String reservationno;
    private Tour tourno;
    private Tourist touristid;

    public Reservation() {
    }

    public Reservation(String reservationno, Tour tourno, Tourist touristid) {
        this.reservationno = reservationno;
        this.tourno = tourno;
        this.touristid = touristid;
    }

    /**
     * @return the reservationno
     */
    public String getReservationno() {
        return reservationno;
    }

    /**
     * @param reservationno the reservationno to set
     */
    public void setReservationno(String reservationno) {
        this.reservationno = reservationno;
    }

    /**
     * @return the tourno
     */
    public Tour getTourno() {
        return tourno;
    }

    /**
     * @param tourno the tourno to set
     */
    public void setTourno(Tour tourno) {
        this.tourno = tourno;
    }

    /**
     * @return the touristid
     */
    public Tourist getTouristid() {
        return touristid;
    }

    /**
     * @param touristid the touristid to set
     */
    public void setTouristid(Tourist touristid) {
        this.touristid = touristid;
    }
      public String toString() {
        return "Reservation{" + "reservationno=" + reservationno + ", tourno=" + tourno + ", touristid=" + touristid + '}';
    }

}
