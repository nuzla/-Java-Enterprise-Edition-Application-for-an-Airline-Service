/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.util.Date;

/**
 *
 * @author Nuzla
 */
public class Tour implements java.io.Serializable {

    private String tourno;
    private TourPlan tourid;
    private String starthotel;
    private String endhotel;
    private Date starttime;
    private Date endtime;

    public Tour() {
    }

    public Tour(String tourno, TourPlan tourid, String starthotel, String endhotel, Date starttime, Date endtime) {
        this.tourno = tourno;
        this.tourid = tourid;
        this.starthotel = starthotel;
        this.endhotel = endhotel;
        this.starttime = starttime;
        this.endtime = endtime;
    }

    /**
     * @return the tourno
     */
    public String getTourno() {
        return tourno;
    }

    /**
     * @param tourno the tourno to set
     */
    public void setTourno(String tourno) {
        this.tourno = tourno;
    }

    /**
     * @return the tourid
     */
    public TourPlan getTourid() {
        return tourid;
    }

    /**
     * @param tourid the tourid to set
     */
    public void setTourid(TourPlan tourid) {
        this.tourid = tourid;
    }

    /**
     * @return the starthotel
     */
    public String getStarthotel() {
        return starthotel;
    }

    /**
     * @param starthotel the starthotel to set
     */
    public void setStarthotel(String starthotel) {
        this.starthotel = starthotel;
    }

    /**
     * @return the endhotel
     */
    public String getEndhotel() {
        return endhotel;
    }

    /**
     * @param endhotel the endhotel to set
     */
    public void setEndhotel(String endhotel) {
        this.endhotel = endhotel;
    }

    /**
     * @return the starttime
     */
    public Date getStarttime() {
        return starttime;
    }

    /**
     * @param starttime the starttime to set
     */
    public void setStarttime(Date starttime) {
        this.starttime = starttime;
    }

    /**
     * @return the endtime
     */
    public Date getEndtime() {
        return endtime;
    }

    /**
     * @param endtime the endtime to set
     */
    public void setEndtime(Date endtime) {
        this.endtime = endtime;
    }

    @Override
    public String toString() {
        return "Tour{" + "tourno=" + tourno + ", tourid=" + tourid + ", starthotel=" + starthotel + ", endhotel=" + endhotel + ", starttime=" + starttime + ", endtime=" + endtime + '}';
    }

}
