/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package tour;


import java.util.List;
import javax.ejb.Remote;
import utils.Reservation;
import utils.Tour;
import utils.TourPlan;
import utils.Tourist;

/**
 *
 * @author Nuzla
 */
@Remote
public interface TourFacadeRemote {

    public void createTourPlan(TourPlan details);

    public void createTour(Tour details);

    public void createTourist(Tourist details);

    public void createReservation(Reservation details);

    public void editTourPlan(TourPlan details);

    public void editTourist(Tourist details);

    public void editTour(Tour details);

    public TourPlan getTourplancb004603(String tourId);

    public Tour getTourcb004603(String tourno);

    public Tourist getTouristcb004603(String touristid);

    public Reservation getReservationcb004603(String reservationno);

    public void removeTourplancb004603(String tourid);

    public void removeTourcb004603(String tourno);

    public void removeTouristcb004603(String touristid);

    public void removeReservationcb004603(String reservationno);

    public List<TourPlan> getAllTourplancb004603();

    public List<Tour> getAllTourcb004603();

    public List<Tourist> getAllTouristcb004603();

    public List<Reservation> getAllReservationcb004603();

   
    
}
