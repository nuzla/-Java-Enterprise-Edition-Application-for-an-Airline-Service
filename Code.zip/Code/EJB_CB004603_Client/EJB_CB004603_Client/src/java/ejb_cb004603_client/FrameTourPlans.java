/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb_cb004603_client;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableRowSorter;
import tour.TourFacadeRemote;
import utils.Reservation;
import utils.Tour;
import utils.TourPlan;

/**
 *
 * @author Nuzla
 */
public class FrameTourPlans extends javax.swing.JInternalFrame {
    private final JTable table;
    private final TableRowSorter<AbstractTableModel> filter;
    private final JScrollPane scrollPane;
    private final JPanel PanelFilter;
    private final JLabel lblFilterBy;
    private final JComboBox<String> comboBox;
    private final JLabel lblRegex;
    private final JTextField textRegex;

    /**
     * Creates new form FrameTours
     */
    public FrameTourPlans() {
        initComponents();
        this.setLayout(new BorderLayout());
        
           this.setDefaultCloseOperation(JInternalFrame.DISPOSE_ON_CLOSE);
                tourFacade= lookupTourFacadeRemote();;
        setTitle("View Tours");
		setResizable(true);
		setClosable(true);
		
				setBounds(100, 100, 640, 480);
		
		AbstractTableModel model = new ToursTableModel();
		
		this.table = new JTable(model);
                
                filter = new TableRowSorter<AbstractTableModel>(model);
		
		this.scrollPane = new JScrollPane(table);
		table.setFillsViewportHeight(true);
		table.setRowSorter(filter);
		
		getContentPane().add(this.scrollPane, BorderLayout.CENTER);
		this.PanelFilter = new JPanel();
		getContentPane().add(this.PanelFilter, BorderLayout.NORTH);
		this.PanelFilter.setLayout(new BoxLayout(this.PanelFilter,
				BoxLayout.X_AXIS));
		
		this.lblFilterBy = new JLabel("Filter by: ");
		this.PanelFilter.add(this.lblFilterBy);
		this.comboBox = new JComboBox<String>();
		this.comboBox.setModel(new DefaultComboBoxModel<String>(new String[] {
				"Tour ID", "Title", "Details", "Capacity","Available"}));
		
                this.comboBox.addItemListener(new ItemListener() {

            @Override
            public void itemStateChanged(ItemEvent e) {
                filter();
            }
        });
                this.PanelFilter.add(this.comboBox);
		this.lblRegex = new JLabel("Filter (Regex):");
		this.PanelFilter.add(this.lblRegex);
		this.textRegex = new JTextField();
		this.textRegex.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				filter();
			}
		});
                
                  
                this.textRegex.getDocument().addDocumentListener(new DocumentListener() {

            @Override
            public void insertUpdate(DocumentEvent e) {
         filter();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                filter();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                filter();
            }
        });
              
		this.PanelFilter.add(this.textRegex);
		this.textRegex.setColumns(16);
		
                available = new JCheckBox("Show only Tour Plans with NO Tours");
                available.addChangeListener(new ChangeListener() {

            @Override
            public void stateChanged(ChangeEvent e) {
                avail = available.isSelected();
                filter();
                
            }
        });
                this.add(available, BorderLayout.SOUTH);
                
		setMaximizable(true);
		
		this.setVisible(true);
	
    }
    JCheckBox available;
    boolean avail;
    
    public static class NoBookingsFilters<AbstractTableModel, Object> extends RowFilter<AbstractTableModel, Object> {

        @Override
        public boolean include(Entry<? extends AbstractTableModel, ? extends Object> entry) {
            
            if(Integer.compare((Short)entry.getValue(3), (Integer)entry.getValue(4))==0)
                return true;
            
            return false;
        
        }
    }

    private void filter()
	{
		RowFilter<AbstractTableModel, Object> rf = null;
		
		int filterBy = comboBox.getSelectedIndex();
		
		if (filterBy == -1)
			return;
		
		try
		{
                    
			rf = RowFilter.regexFilter(textRegex.getText(), filterBy);
                        
                        if(avail){
                       List<RowFilter<AbstractTableModel,Object>> filters = new ArrayList<RowFilter<AbstractTableModel,Object>>(2);
                       filters.add(rf);
                       
                       
                       filters.add(new NoBookingsFilters<AbstractTableModel, Object>());
                       
                       
                       rf=RowFilter.andFilter(filters);
                        
                        }
		}
		catch (java.util.regex.PatternSyntaxException e)
		{
			return;
		}
                
		filter.setRowFilter(rf);
		pack();
		setVisible(true);
	}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setTitle("View Tour Plans");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 394, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 286, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

    private static class ToursTableModel extends AbstractTableModel {
private List<TourPlan> tours;
        public ToursTableModel() {
            tours = new ArrayList<TourPlan>();
            
            tours.addAll(tourFacade.getAllTourplancb004603());
            
            
            
        }

        @Override
        public int getRowCount() {
            return tours.size();
        }

        @Override
        public int getColumnCount() {
        return 5;
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            TourPlan t = tours.get(rowIndex);
            
            
		switch (columnIndex)
		{
			case 0:
				return t.getTourid();
			case 1:
				return t.getTitle();
			case 2:
				return t.getDetails();
			case 3:
				return t.getCapacity();
			case 4:
                            
				int x= t.getCapacity();
                            
                            for(Reservation r:tourFacade.getAllReservationcb004603())
                                if(r.getTourno().getTourid().getTourid().equalsIgnoreCase(t.getTourid()))
                                    x--;
                            return x;
                        
                  
		}
                
                return null;
        }
        
        @Override
        public String getColumnName(int col)
	{
		switch (col)
		{
			case 0:
				return "Tour ID";
			case 1:
				return "Title";
			case 2:
				return "Details";
			case 3:
		return "Capacity";
                        case 4: return "Available";
		}
		return null;
		
	}
        
    }
    
    private static TourFacadeRemote tourFacade;
    
        private TourFacadeRemote lookupTourFacadeRemote() {
        try {
            Context c = new InitialContext();
            return (TourFacadeRemote) c.lookup("tourFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }
}
